package cz.machacek.jhunter.core

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CoreApplicationTests {

	@Test
	fun contextLoads() {
	}

}
